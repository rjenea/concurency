package Lab1_Withdraw;

public interface BankUpdater {
	public void update(String message);
	public void updateAccount(String newBalance);
}
