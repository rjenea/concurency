package Lab7_Cancellation;

public interface VerboseUpdater {
	
	public void update(String text);

}
