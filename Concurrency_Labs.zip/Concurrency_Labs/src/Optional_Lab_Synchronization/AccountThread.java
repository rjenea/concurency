package Optional_Lab_Synchronization;

// ** TO DO implement this class
// Exercise 1  (enhanced in Exercise 2)
public class AccountThread // extends Thread
{
    // ** TO DO add two state variables
    // an Account called account
    // a double called amount

    // ** TO DO implement a contructor taking a String and a double
    //
    //
        // Initialize state variables

    //

    //** TO DO implement run() method
    //
      	// create a local boolean called withdrawOK (set to false)
       	// loop while withdrawOK is not OK (i.e. false)
       	//
       		// add synchronized block on account object
       		//
              		// assign withdrawOK with return from account withdraw()
               		// if (!withdrawOK)
              		//
               			// try an account.wait() and catch an InterruptedException e
               		// end if
       		//
        //End of loop

}
