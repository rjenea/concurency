package Lab4_Executor_Withdraw;

public interface BankUpdater {
	public void update(String message);
	public void updateAccount(String newBalance);
}
